#include <stdio.h>

int
run (const char *argument)
{
  printf ("Hello, %s!\n", argument);
  return 0;
}
