void hello ();

int
main (int argc, char *argv[])
{
  hello ("World");
  exit (0);
}

