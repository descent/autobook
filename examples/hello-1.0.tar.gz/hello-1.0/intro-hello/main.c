void hello ();

int
main (int argc, char *argv[])
{
  hello ("\tWorld \r\n");
  exit (0);
}

