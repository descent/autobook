extern void gratuitous          (void);
extern void set_program_name    (char *path);
extern void error               (char *message);

